from typing import Generic, TypeVar

# Create a generic Out type to indicate out parameters
T = TypeVar('T')


class Out(Generic[T]):
    """
    Indicates that a parameter is an 'out' parameter.
    """

class AttributeProperty(Generic[T]):
    """
    Indicates that the property is an attribute property.
    """
